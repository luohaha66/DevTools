复制 Crack 目录下的 vspdpro.exe 文件覆盖软件安装目录中同名的文件。
软件默认安装目录为 C:\Program Files\Electronic Team\Virtual Serial Port Driver 10